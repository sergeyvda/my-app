package com.mycompany.app;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

public class App 
{

    public static void main(String[] args) throws Exception {
	String port = System.getenv("MY_APP_PORT");
        int portNum = Integer.parseInt(port != null ? port : "80");
        HttpServer server = HttpServer.create(new InetSocketAddress(portNum), 0);
        server.createContext("/api", new ApiHandler());
        server.setExecutor(null); // creates a default executor
        server.start();
    }

    static class ApiHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            System.out.println( "GET /api" );
            String response = "This is the response from the api. It works correctly.\n";
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
            System.out.println( "HTTP response code 200" );
        }
    }

}
